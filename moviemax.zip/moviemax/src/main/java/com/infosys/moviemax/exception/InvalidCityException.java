package com.infosys.moviemax.exception;

public class InvalidCityException extends MovieMaxException{
	private static final long SerialVersionUID=1L;
	public InvalidCityException(String message){
		super(message);
	}

}
