package com.infosys.moviemax.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.moviemax.exception.InvalidCityException;
import com.infosys.moviemax.exception.InvalidEmailException;
import com.infosys.moviemax.exception.InvalidNameException;
import com.infosys.moviemax.exception.InvalidOptionException;
import com.infosys.moviemax.exception.InvalidPhoneException;
import com.infosys.moviemax.exception.MovieMaxException;
import com.infosys.moviemax.model.User;
import com.infosys.moviemax.repository.UserRepository;

@Service
public class RegistrationService {
	@Autowired
	private UserRepository userRepository;
	String regex1="^[a-zA-Z0-9]{4,15}+$";
	public String registerUser(User user) throws MovieMaxException {
		String registrationMessage=null;
		validateUser(user);
		registrationMessage=userRepository.registerUser();
		return registrationMessage;
		
	}
	private void validateUser(User user) throws MovieMaxException {
		// TODO Auto-generated method stub
		
		if(!isValidName(user.getName()))
			throw new InvalidNameException("RegistrationService.INVALID_NAME");
		if(!isValidEmail(user.getEmail()))
			throw new InvalidEmailException("RegistrationService.INVALID_EMAIL");
		if(!isValidCity(user.getCity()))
			throw new InvalidCityException("RegistrationService.INVALID_CITY");
		if(!isValidPhone(user.getPhone()))
			throw new InvalidPhoneException("RegistrationService.INVALID_PHONE");
		if(!isValidOption(user.getOption()))
			throw new InvalidOptionException("RegistrationService.INVALID_OPTION");
	
	}
	private boolean isValidOption(String option) {
		// TODO Auto-generated method stub
	Boolean	b1=false;
	String regex4="[1-5]{1}";
	Pattern pattern5=Pattern.compile(regex4);
	Matcher matcher5=pattern5.matcher(option);
	if(matcher5.matches())
		b1=true;
	
	
		
		return b1;
	}
	private boolean isValidPhone(String phone) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		String regex2="[0-9]{10}";
		Pattern pattern1=Pattern.compile(regex2);
		Matcher matcher1=pattern1.matcher(phone);
		if(matcher1.matches())
			b1=true;
		return b1;
	}
	private boolean isValidCity(String city) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		Pattern pattern2=Pattern.compile(regex1);
		Matcher matcher2=pattern2.matcher(city);
		if(matcher2.matches())
			b1=true;
		return b1;
	}
	private boolean isValidEmail(String email) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		String regex3="^[A-Za-z0-9+_.-]+@(.+)$";
		Pattern pattern4=Pattern.compile(regex3);
		Matcher matcher4=pattern4.matcher(email);
		if(matcher4.matches())
			b1=true;
		return b1;
	}
	private boolean isValidName(String name) {
		// TODO Auto-generated method stub
		Boolean b1=false;
		Pattern pattern3=Pattern.compile(regex1);
		Matcher matcher3=pattern3.matcher(name);
		if(matcher3.matches())
			b1=true;
		
		return b1;
	}
	
}
