package com.infosys.moviemax.exception;

public class MovieMaxException extends Exception {
	private static final long SerailVersionUID=1L;
	public  MovieMaxException(String message) {
		super(message);
	}

}
