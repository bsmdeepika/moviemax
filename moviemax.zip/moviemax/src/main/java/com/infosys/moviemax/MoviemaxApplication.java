package com.infosys.moviemax;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import com.infosys.moviemax.exception.InvalidOptionException;
import com.infosys.moviemax.model.User;
import com.infosys.moviemax.service.RegistrationService;

@SpringBootApplication
@PropertySource
	(value= {"classpath:configuration.properties"})

public class MoviemaxApplication implements CommandLineRunner {
	@Autowired
	private Environment environment;
	@Autowired
	private ApplicationContext context;
	public static void main(String[] args) {
		
		SpringApplication.run(MoviemaxApplication.class, args);
	}
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		try {
			
		
			
			
			User user=new User();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter name:");
			String name=sc.next();
			System.out.println("Enter email");
			String email=sc.next();
			System.out.println("Enter city:");
			String city=sc.next();
			System.out.println("Enter mobile:");
			String phone=sc.next();
			
			user.setCity(city);
			user.setEmail(email);
			user.setName(name);
			user.setPhone(phone);
			
			System.out.println("1.SpiderMan");
			System.out.println("2.Thor");
			System.out.println("3.Logan");
			System.out.println("4.Conjuring2");
			System.out.println("5.StarWars");
			
			System.out.println("select one movie and enter:");
			String movie=sc.next();
			user.setOption(movie);
			
			
			RegistrationService registrationService=(RegistrationService) context.getBean("registrationService");
			String registrationMessage=registrationService.registerUser(user);
			
			System.out.println(environment.getProperty(registrationMessage));
			
			
		}
		catch(Exception e) {
			System.out.println(environment.getProperty(e.getMessage()));
		}
		
	}

}
