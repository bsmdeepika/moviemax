package com.infosys.moviemax.exception;

public class InvalidPhoneException extends MovieMaxException{
	private static final long SerialVersionUID=1L;
	public InvalidPhoneException(String message) {
		super(message);
	}

}
