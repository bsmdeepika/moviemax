package com.infosys.moviemax.exception;

public class InvalidNameException extends MovieMaxException {
	private static final long SerialVersionUID=1L;
	public InvalidNameException(String message) {
		super(message);
	}

}
