package com.infosys.moviemax.exception;

public class InvalidOptionException extends MovieMaxException{
	private static final long SerialVersionUID=1L;
	public InvalidOptionException(String message) {
		super(message);
	}

}
