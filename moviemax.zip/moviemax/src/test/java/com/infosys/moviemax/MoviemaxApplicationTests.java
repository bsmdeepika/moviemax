package com.infosys.moviemax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoviemaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
